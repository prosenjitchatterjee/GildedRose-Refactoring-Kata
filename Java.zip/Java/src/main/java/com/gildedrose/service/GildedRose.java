package com.gildedrose.service;

/**
 * @author Prosenjit
 *
 */
public interface GildedRose {
  
    public void updateQuality();
}